# Utilisation:

Lancer BellmanFordTest en tant que Java Application: donne en sortie console un résumé des tests passés et ratés.